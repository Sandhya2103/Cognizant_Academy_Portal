

drop procedure [dbo].[sp_BU_EmployeeDetails_Fetch]
--PROC


CREATE procedure [dbo].[sp_BU_EmployeeDetails_Fetch]
(
 @category  varchar(20),
 @vertical varchar(20)
)
as 
begin

if @category='Overall'
begin
select location as Location,batchCode as 'Batch Code',batchOwnerName as 'BatchOwner Name', track as Track,batchStartDate as 'Batch Start Date',plannedGraduationDate as 'Planned Graduation Date',
monthOfGraduation as 'Month Of Graduation',actualGraduationDate as 'Actual Graduation Date',reasonForExtension as 'Reason For Extension',traineeStatus as 'Trainee Status',
trainingVertical as 'Training Vertical',intakeMonth as 'Intake Month',dateOfJoining as DOJ,associateName as 'Associate Name',collegeName as 'College Name',qualification as 'Qualification',
branch as Branch,designation as Designation from tabEmployeeDetails where trainingVertical=@vertical;

end
else  

begin
select location as Location,batchCode as 'Batch Code',batchOwnerName as 'BatchOwner Name', track as Track,batchStartDate as 'Batch Start Date',plannedGraduationDate as 'Planned Graduation Date',
monthOfGraduation as 'Month Of Graduation',actualGraduationDate as 'Actual Graduation Date',reasonForExtension as 'Reason For Extension',traineeStatus as 'Trainee Status',
trainingVertical as 'Training Vertical',intakeMonth as 'Intake Month',dateOfJoining as DOJ,associateName as 'Associate Name',collegeName as 'College Name',qualification as 'Qualification',
branch as Branch,designation as Designation from tabEmployeeDetails where traineeStatus=@category and trainingVertical=@vertical;
end

end
--END

--AVM CHART START
drop procedure sp_ChartData_BU_Vertical

CREATE procedure sp_ChartData_BU_Vertical
(
@category varchar(20),
@vertical varchar(20)
)
as
begin
declare @headCount_Intraining int
declare @headCount_Graduated int
declare @headCount_Resigned int

if @category='Overall'
begin
select @headCount_Intraining = count(associateId) from tabEmployeeDetails where trainingVertical=@vertical and traineeStatus='Intraining'
select @headCount_Graduated =  count(associateId) from tabEmployeeDetails where trainingVertical=@vertical and traineeStatus='Graduated'
select @headCount_Resigned = count(associateId) from tabEmployeeDetails where trainingVertical=@vertical and traineeStatus='Resigned'
end

else if @category='Graduated'
begin
select @headCount_Graduated = count(associateId) from tabEmployeeDetails where trainingVertical=@vertical and traineeStatus='Graduated'

end

else if @category='Intraining'
begin
select @headCount_Intraining = count(associateId) from tabEmployeeDetails where trainingVertical=@vertical and traineeStatus='Intraining'
end

else if @category='Resigned'
begin
select @headCount_Resigned = count(associateId) from tabEmployeeDetails where trainingVertical=@vertical and traineeStatus='Resigned'
end



select @headCount_Intraining as 'Intraining', @headCount_Graduated as 'Graduated', @headCount_Resigned as 'Resigned'
end



--CHART END

--date chart bu vertical

CREATE procedure sp_Date_ChartData_BU_Vertical
(
@category varchar(20),
@vertical varchar(20),
@startpar varchar(20),
@endpar varchar(20)
)
as
begin
declare @headCount_Intraining int
declare @headCount_Graduated int
declare @headCount_Resigned int

if @category='Overall'
begin
select @headCount_Intraining = count(associateId) from tabEmployeeDetails where trainingVertical=@vertical and traineeStatus='Intraining' and batchStartDate between @startpar and @endpar 
select @headCount_Graduated =  count(associateId) from tabEmployeeDetails where trainingVertical=@vertical and traineeStatus='Graduated' and batchStartDate between @startpar and @endpar 
select @headCount_Resigned = count(associateId) from tabEmployeeDetails where trainingVertical=@vertical and traineeStatus='Resigned' and batchStartDate between @startpar and @endpar 
end

else if @category='Graduated'
begin
select @headCount_Graduated = count(associateId) from tabEmployeeDetails where trainingVertical=@vertical and traineeStatus='Graduated' and batchStartDate between @startpar and @endpar 

end

else if @category='Intraining'
begin
select @headCount_Intraining = count(associateId) from tabEmployeeDetails where trainingVertical=@vertical and traineeStatus='Intraining' and batchStartDate between @startpar and @endpar 
end

else if @category='Resigned'
begin
select @headCount_Resigned = count(associateId) from tabEmployeeDetails where trainingVertical=@vertical and traineeStatus='Resigned' and batchStartDate between @startpar and @endpar 
end



select @headCount_Intraining as 'Intraining', @headCount_Graduated as 'Graduated', @headCount_Resigned as 'Resigned'
end
--end