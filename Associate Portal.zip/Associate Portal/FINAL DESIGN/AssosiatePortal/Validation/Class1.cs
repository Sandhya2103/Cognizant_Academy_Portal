﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Validation
{
    public class Class1
    {
        public string userID;
        public string pass;
        public string MainAdminID;
        public string MainAdminpass;
        public string buID;
        public string bupass;
        public string startdate;
        public string enddate;

    }
}
