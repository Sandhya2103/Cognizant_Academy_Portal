﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Validation;
using Functions;

namespace WebApplication1
{
    public partial class Academylogin : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void btnsubmitacademy_Click(object sender, EventArgs e)
        {

            Class1 t = new Class1();
            t.userID = txtAcademyid.Text;
            t.pass = txtAcademyPassword.Text;
            lblLogin.Visible = false;

            if (Statements.AdminLogin(t) == 1)
            {
                Response.Redirect("~/Academydetails.aspx");
            }
            else
            {
                lblLogin.Visible = true;
                lblLogin.Text = "Invalid Credentials";
            }
        }

      
    }
}