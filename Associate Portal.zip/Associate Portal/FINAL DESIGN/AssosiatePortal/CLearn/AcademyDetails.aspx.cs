﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.DataVisualization.Charting;


namespace CLearn
{
    public partial class AcademyDetails : Page

    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData("Overall");
            }


        }

        private void GetChartData(string category)
        {
            string cs = ConfigurationManager.ConnectionStrings["dbconstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("sp_ChartData_Academy", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@category", category);
                Series series = Chart1.Series["Default"];
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                string[] xValues = { "AVM", "CDB", "QEA" };
                int[] yValues = new int[3];
                while (rdr.Read())
                {
                    int i = 0;
                    foreach (string s in xValues)
                    {
                        yValues[i] = (Int32)rdr[s];
                        i++;
                    }
                }
               Chart1.Series["Default"].Points.DataBindXY(xValues, yValues);
                Chart1.Series["Default"].ChartType = SeriesChartType.Pie;
                Chart1.Series["Default"]["PieLabelStyle"] = "Visible";
                Chart1.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
                Chart1.Legends[0].Enabled = true;
            }
        }


        private void GetChartForDates(string category, string sd, string ed)
        {
            string cs = ConfigurationManager.ConnectionStrings["dbconstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("sp_Date_ChartData_Academy", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@category", category);
                cmd.Parameters.AddWithValue("@start", sd);
                cmd.Parameters.AddWithValue("@end", ed);
                Series series = Chart1.Series["Default"];
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                string[] xValues = { "AVM", "CDB", "QEA" };
                int[] yValues = new int[3];
                while (rdr.Read())
                {
                    int i = 0;
                    foreach (string s in xValues)
                    {
                        yValues[i] = (Int32)rdr[s];
                        i++;
                    }
                }
                Chart1.Series["Default"].Points.DataBindXY(xValues, yValues);
                Chart1.Series["Default"].ChartType = SeriesChartType.Pie;
                Chart1.Series["Default"]["PieLabelStyle"] = "Visible";
                Chart1.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
                Chart1.Legends[0].Enabled = true;
            }
        }




        private void GetChartForGrad(string category, string date)
        {
            string cs = ConfigurationManager.ConnectionStrings["dbconstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("sp_Date_ChartData_Grad", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@category", category);
                cmd.Parameters.AddWithValue("@date", DateTime.Parse(date));
                Series series = Chart1.Series["Default"];
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                string[] xValues = { "AVM", "CDB", "QEA" };
                int[] yValues = new int[3];
                while (rdr.Read())
                {
                    int i = 0;
                    foreach (string s in xValues)
                    {
                        yValues[i] = (Int32)rdr[s];
                        i++;
                    }
                }
                Chart1.Series["Default"].Points.DataBindXY(xValues, yValues);
                Chart1.Series["Default"].ChartType = SeriesChartType.Pie;
                Chart1.Series["Default"]["PieLabelStyle"] = "Visible";
                Chart1.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
                Chart1.Legends[0].Enabled = true;
            }
        }





        private void BindData(string cat)
        {
            GradFlag.Value = "0";
            SearchFlag.Value = "0";
            string category = cat;
            GetChartData(category);
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {                
                SqlCommand commandToExecute = new SqlCommand("sp_fetch_data", con);
                commandToExecute.Parameters.AddWithValue("@category", cat);

                SqlDataAdapter da = new SqlDataAdapter(commandToExecute);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataSet ds = new DataSet();
              
                    da.Fill(ds);
               

                GridViewacademy.DataSource = ds;
                GridViewacademy.DataBind();
                GetChartData(category);

            }

        }

        //public override void VerifyRenderingInServerForm(Control control)
        //{
        //}

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GridViewacademy.AllowPaging = false;
            
               // this.BindData(str);

                //GridViewacademy.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GridViewacademy.HeaderRow.Cells)
                {
                    cell.BackColor = GridViewacademy.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GridViewacademy.Rows)
                {
                    //row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GridViewacademy.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GridViewacademy.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GridViewacademy.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(sw.ToString());
               // Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            //base.VerifyRenderingInServerForm(control);
        }



        protected void btnintrainingacademy_Click(object sender, EventArgs e)
        {
            traineeStatusFlag.Value = "2";
            string category = "Intraining";
            BindData(category);
            GetChartData(category);
            Label2.Visible = true;
            TextBoxGrad.Visible = true;
            GraduationMonth.Visible = true;
        }


        protected void btngraduatedacademy_Click(object sender, EventArgs e)
        {
            
            traineeStatusFlag.Value = "3";
            string category = "Graduated";
            BindData(category);
            GetChartData(category);
            Label2.Visible = true;
            TextBoxGrad.Visible = true;
            GraduationMonth.Visible = true;

        }

        protected void btnresignedacademy_Click(object sender, EventArgs e)
        {          
            traineeStatusFlag.Value = "4";
            string category = "Resigned";
            BindData(category);
            GetChartData(category);
            int flag = int.Parse(GradFlag.Value);
            Label2.Visible = false;
            TextBoxGrad.Visible = false;
            GraduationMonth.Visible = false;
            /*if (flag == 1)
            {
                TextBoxGrad.Visible = false;
                GraduationMonth.Visible = false;
            }*/
        }



        protected void GridViewacademy_PageIndexChanging1(object sender, GridViewPageEventArgs e)
        {
           int flag = int.Parse(traineeStatusFlag.Value);
            string cat="";
            if (flag == 1)
                {
                    cat="Overall";
                }
                else if (flag == 2)
                {
                    cat="Intraining";
                }
                else if (flag == 3)
                {
                    cat="Graduated";
                }
                else if (flag == 4)
                {
                    cat="Resigned";
                }
             if (GradFlag.Value == "0" && SearchFlag.Value == "0")
            {   
                BindData(cat);
                GridViewacademy.PageIndex = e.NewPageIndex;
                GridViewacademy.DataBind();
            }
            else if(GradFlag.Value =="1" && SearchFlag.Value == "0")
            {
                 BindDataGrad(cat);

                GridViewacademy.PageIndex = e.NewPageIndex;
                GridViewacademy.DataBind();
                
            }
             else if(GradFlag.Value =="0" && SearchFlag.Value== "1")
             {
                 BindDataSearch(cat);
                 GridViewacademy.PageIndex = e.NewPageIndex;
                GridViewacademy.DataBind();
     
             }

           
          
           
        }

        protected void btnoverallacademy_Click(object sender, EventArgs e)
        {
           
            traineeStatusFlag.Value = "1";
            BindData("Overall");
            Label2.Visible = true;
            TextBoxGrad.Visible = true;
            GraduationMonth.Visible = true;
        }

        protected void SearchButton_Click(object sender, EventArgs e)
        {
            //set new hidden flag = serach flag
            SearchFlag.Value = "1";
            GradFlag.Value = "0";
            int flag = int.Parse(traineeStatusFlag.Value);
            if (flag == 1)
            {
                BindDataSearch("Overall");
            }
            else if (flag == 2)
            {
                BindDataSearch("Intraining");
            }
            else if (flag == 3)
            {
                BindDataSearch("Graduated");
            }
            else if (flag == 4)
            {
                BindDataSearch("Resigned");
            }

       
        }

        


        protected void GraduationMonth_Click(object sender, EventArgs e)
        {
            GradFlag.Value="1";
            SearchFlag.Value = "0";
            //GridViewacademy.Visible = false;
            int searchflag = int.Parse(traineeStatusFlag.Value);
            if (searchflag == 1)
            {   
                BindDataGrad("Overall");
            }
            else if (searchflag == 2)
            {
                BindDataGrad("Intraining");
            }
            else if (searchflag == 3)
            {
                BindDataGrad("Graduated");
            }
                       
        }
        private void BindDataGrad(string parm)
        {
           string graduation = TextBoxGrad.Text.ToString();
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand commandToExecute = new SqlCommand("sp_Grad_data", con);
                commandToExecute.Parameters.AddWithValue("@category", parm);
                commandToExecute.Parameters.AddWithValue("@date", DateTime.Parse(graduation));

                SqlDataAdapter da = new SqlDataAdapter(commandToExecute);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataSet ds = new DataSet();
               
                    da.Fill(ds);
                    GridViewacademy.DataSource = ds;
                    GridViewacademy.DataBind();
                    GetChartForGrad(parm, graduation);
                
            }
        }
      
        private void BindDataSearch(string param)
        {
            string sd = TextStartDate.Text;
            string ed = TextEndDate.Text;
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand commandToExecute = new SqlCommand("sp_Search_data", con);
                commandToExecute.Parameters.AddWithValue("@category", param);
                commandToExecute.Parameters.AddWithValue("@start", DateTime.Parse(sd));
                commandToExecute.Parameters.AddWithValue("@end", DateTime.Parse(ed));
                SqlDataAdapter da = new SqlDataAdapter(commandToExecute);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataSet ds = new DataSet();
              
                    da.Fill(ds);
                GridViewacademy.DataSource = ds;
                GridViewacademy.DataBind();
                GetChartForDates(param, sd, ed);
                /* if (ds != null && ds.Tables.Count > 0)
                 {
                     // Condition to check if dataset tables contains data or not
                    // if (ds.Tables[0].Rows.Count > 0)
                    // {
                         NO_REC.Visible = false;
                         GridViewacademy.DataSource = ds;
                         GridViewacademy.DataBind();
                         GetChartForDates(param, sd, ed);
                   //  }
                 }
                 else
                 {
                     GridViewacademy.Visible = false;
                     NO_REC.Visible = true;
                     NO_REC.Text = "No Records Found";
                 }*/


                //Label visibility check not yet added
                /* SqlDataReader sdr = con.ExecuteReader();
                 if (sdr.Read())
                 {
                     GridViewacademy.DataSource = ds;
                     GridViewacademy.DataBind();
                     Label1.Visible = false;
                     if (param == "Intraining")
                     {
                         param = "Training";
                     }

                     GetChartForDates(param, sd, ed);
                 }
                 else
                 {
                     Label1.Visible = true;
                     GridViewacademy.Visible = false;
                     Label1.Text = "NO RECORDS FOUND";

                 }*/


                //GetChartForDates(param, sd, ed);
            }
        }

        
               protected void AdminLog_Click1(object sender, EventArgs e)
        {
            Response.Redirect("Homepage.aspx");
        }

        protected void Chart1_Load(object sender, EventArgs e)
        {

        }
    }



    }









