﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.DataVisualization.Charting;

namespace WebApplication1
{
    public partial class Demand_Supply : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

       
        protected void Academy_Click(object sender, EventArgs e)
        {
            Response.Redirect("DS_Academy.html");
        }

        protected void BU_Click(object sender, EventArgs e)
        {
            Response.Redirect("DS_BU.html");
        }
    }
}