﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Validation;
using Functions;

namespace CLearn
{
    public partial class Admin_BU : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void btnAVM_Click(object sender, EventArgs e)
        {
            Response.Redirect("AVM.aspx");
        }

        protected void btnCDB_Click(object sender, EventArgs e)
        {
            Response.Redirect("CDB.aspx");
        }

        protected void btnQEA_Click(object sender, EventArgs e)
        {
            Response.Redirect("QEA.aspx");
        }

        protected void btnIS_Click(object sender, EventArgs e)
        {
            Response.Redirect("IS.aspx");
        }

        protected void AdminLog_Click(object sender, EventArgs e)
        {
            Response.Redirect("Homepage.aspx");
        }

    }
}