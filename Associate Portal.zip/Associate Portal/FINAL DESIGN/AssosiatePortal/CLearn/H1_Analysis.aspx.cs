﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class H1_Analysis : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           // Response.Write("<script>alert('Your text');</script>");
        }
        

      

        protected void PPT_Click(object sender, EventArgs e)
        {
          
        }
    }
}