﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.DataVisualization.Charting;

namespace WebApplication1
{
    public partial class QEA : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string title = "Greetings";
            string body = " NOTE: This information is Confidential and CANNOT be shared with third partiies (e.g. Clients). @ This data of Cognizant Associates is being shared with the BU purely for planning and risk mitigation purposes *provided* that: @ 1.The BU agrees to use this information for lawful,non discriminatory purposes. @ 2.The BU agrees to protect this Cognizant/associate information from disclosures to third parties. @ 3.The BU shares this information with its organization to management/leads strictly on a need-to-know basis.";
            body = body.Replace("@", "<br/>");
            ClientScript.RegisterStartupScript(this.GetType(), "Popup", "ShowPopup('" + title + "', '" + body + "');", true);

                Consolidate();
                ConsolidateChart();
                sd.Visible = false;
                ed.Visible = false;
                SearchButton.Visible = false;
                TextStartDate.Visible = false;
                TextEndDate.Visible = false;
                GraduationMonth.Visible = false;
                TextBoxGrad.Visible = false;
                Label2.Visible = false;
            }
        }

        private void GetChartData(string category)
        {
            /*string cs = ConfigurationManager.ConnectionStrings["dbconstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("sp_ChartData_BU_Vertical", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@category", category);
                cmd.Parameters.AddWithValue("@vertical", "QEA");
                Series series = ChartQEA.Series["Series1"];
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    series.Points.AddXY("InTraining", rdr["Intraining"].ToString());
                    series.Points.AddXY("Graduated", rdr["Graduated"].ToString());
                    series.Points.AddXY("Resigined", rdr["Resigned"].ToString());
                }
            }*/

            string cs = ConfigurationManager.ConnectionStrings["dbconstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("sp_ChartData_BU_Vertical", con);
                cmd.CommandType = CommandType.StoredProcedure;
                string cat = category;

                cmd.Parameters.AddWithValue("@category", category);
                cmd.Parameters.AddWithValue("@vertical", "QEA");
                Series series = ChartQEA.Series["Default"];
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                if (cat == "Intraining")
                {
                    string[] xTrainValues = { "Intraining" };
                    int[] yTrainValues = new int[1];
                    while (rdr.Read())
                    {
                        int i = 0;
                        foreach (string s in xTrainValues)
                        {
                            yTrainValues[i] = Convert.ToInt32(rdr[s]);
                            i++;
                        }
                    }

                    ChartQEA.Series["Default"].Points.DataBindXY(xTrainValues, yTrainValues);
                    ChartQEA.Series["Default"].ChartType = SeriesChartType.Pie;
                    ChartQEA.Series["Default"]["PieLabelStyle"] = "Visible";
                    ChartQEA.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
                    ChartQEA.Legends[0].Enabled = true;
                }
                else if (cat == "Graduated")
                {
                    string[] xGradValues = { "Graduated" };
                    int[] yGradValues = new int[1];
                    while (rdr.Read())
                    {
                        int i = 0;
                        foreach (string s in xGradValues)
                        {
                            yGradValues[i] = Convert.ToInt32(rdr[s]);
                            i++;
                        }
                    }

                    ChartQEA.Series["Default"].Points.DataBindXY(xGradValues, yGradValues);
                    ChartQEA.Series["Default"].ChartType = SeriesChartType.Pie;
                    ChartQEA.Series["Default"]["PieLabelStyle"] = "Visible";
                    ChartQEA.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
                    ChartQEA.Legends[0].Enabled = true;
                }
                else if (cat == "Resigned")
                {
                    string[] xResValues = { "Resigned" };
                    int[] yResValues = new int[1];
                    while (rdr.Read())
                    {
                        int i = 0;
                        foreach (string s in xResValues)
                        {
                            yResValues[i] = Convert.ToInt32(rdr[s]);
                            i++;
                        }
                    }

                    ChartQEA.Series["Default"].Points.DataBindXY(xResValues, yResValues);
                    ChartQEA.Series["Default"].ChartType = SeriesChartType.Pie;
                    ChartQEA.Series["Default"]["PieLabelStyle"] = "Visible";
                    ChartQEA.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
                    ChartQEA.Legends[0].Enabled = true;
                }
                else
                {
                    string[] xValues = { "Intraining", "Graduated", "Resigned" };
                    int[] yValues = new int[3];
                    while (rdr.Read())
                    {
                        int i = 0;
                        foreach (string s in xValues)
                        {
                            yValues[i] = Convert.ToInt32(rdr[s]);
                            i++;
                        }
                    }


                    ChartQEA.Series["Default"].Points.DataBindXY(xValues, yValues);
                    ChartQEA.Series["Default"].ChartType = SeriesChartType.Pie;
                    ChartQEA.Series["Default"]["PieLabelStyle"] = "Visible";
                    ChartQEA.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
                    ChartQEA.Legends[0].Enabled = true;
                }
            }



        }


        private void GetChartForGrad(string category, string date)
        {
            /* string cs = ConfigurationManager.ConnectionStrings["dbconstr"].ConnectionString;
             using (SqlConnection con = new SqlConnection(cs))
             {
                 SqlCommand cmd = new SqlCommand("BU_ChartData_Grad", con);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@category", category);
                 cmd.Parameters.AddWithValue("@vertical", "QEA");
                 cmd.Parameters.AddWithValue("@date", DateTime.Parse(date));
                 Series series = ChartQEA.Series["Series1"];
                 con.Open();
                 SqlDataReader rdr = cmd.ExecuteReader();
                 while (rdr.Read())
                 {
                     series.Points.AddXY("InTraining", rdr["Intraining"].ToString());
                     series.Points.AddXY("Graduated", rdr["Graduated"].ToString());
                     //series.Points.AddXY("Resigined", rdr["Resigned"].ToString());
                 }
             }*/

            string cs = ConfigurationManager.ConnectionStrings["dbconstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("BU_ChartData_Grad", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@category", category);
                cmd.Parameters.AddWithValue("@vertical", "QEA");
                cmd.Parameters.AddWithValue("@date", DateTime.Parse(date));
                Series series = ChartQEA.Series["Default"];
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();

                if (category == "Graduated")
                {
                    string[] xGradValues = { "Graduated" };
                    int[] yGradValues = new int[1];
                    while (rdr.Read())
                    {
                        int i = 0;
                        foreach (string s in xGradValues)
                        {
                            yGradValues[i] = Convert.ToInt32(rdr[s]);
                            i++;
                        }
                    }
                    ChartQEA.Series["Default"].Points.DataBindXY(xGradValues, yGradValues);
                    ChartQEA.Series["Default"].ChartType = SeriesChartType.Pie;
                    ChartQEA.Series["Default"]["PieLabelStyle"] = "Visible";
                    ChartQEA.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
                    ChartQEA.Legends[0].Enabled = true;
                }

                else
                {

                    string[] xValues = { "Intraining" };
                    int[] yValues = new int[1];
                    while (rdr.Read())
                    {
                        int i = 0;
                        foreach (string s in xValues)
                        {
                            yValues[i] = Convert.ToInt32(rdr[s]);
                            i++;
                        }
                    }
                    ChartQEA.Series["Default"].Points.DataBindXY(xValues, yValues);
                    ChartQEA.Series["Default"].ChartType = SeriesChartType.Pie;
                    ChartQEA.Series["Default"]["PieLabelStyle"] = "Visible";
                    ChartQEA.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
                    ChartQEA.Legends[0].Enabled = true;
                }
            }





        }




        private void BindData(string cat)
        {
            GradFlag.Value = "0";
            SearchFlag.Value = "0";
            string category = cat;
            GetChartData(category);
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand commandToExecute = new SqlCommand("sp_BU_EmployeeDetails_Fetch", con);
                commandToExecute.Parameters.AddWithValue("@category", cat);
                commandToExecute.Parameters.AddWithValue("@vertical", "QEA");
                SqlDataAdapter da = new SqlDataAdapter(commandToExecute);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewQEA.DataSource = ds;
                GridViewQEA.DataBind();
            }

        }


        protected void ImageButtonQEA_Click(object sender, ImageClickEventArgs e)
        {

            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GridViewQEA.AllowPaging = false;
                // this.BindData();

                //GridViewacademy.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GridViewQEA.HeaderRow.Cells)
                {
                    cell.BackColor = GridViewQEA.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GridViewQEA.Rows)
                {
                    //row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GridViewQEA.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GridViewQEA.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GridViewQEA.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(sw.ToString());
                // Response.Output.Write();
                Response.Flush();
                Response.End();
            }
        }


        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }

        protected void btnintrainingQEA_Click(object sender, EventArgs e)
        {
            traineeStatusFlag.Value = "2";
            string category = "Intraining";
            BindData(category);
            Label2.Visible = true;
            TextBoxGrad.Visible = true;
            GraduationMonth.Visible = true;
            sd.Visible = true;
            ed.Visible = true;
            SearchButton.Visible = true;
            TextStartDate.Visible = true;
            TextEndDate.Visible = true;
        }

        protected void btngraduatedQEA_Click(object sender, EventArgs e)
        {
            string category = "Graduated";
            traineeStatusFlag.Value = "3";
            BindData(category);
            Label2.Visible = true;
            TextBoxGrad.Visible = true;
            GraduationMonth.Visible = true;
            sd.Visible = true;
            ed.Visible = true;
            SearchButton.Visible = true;
            TextStartDate.Visible = true;
            TextEndDate.Visible = true;
        }

        protected void btnresignedQEA_Click(object sender, EventArgs e)
        {
            string category = "Resigned";
            traineeStatusFlag.Value = "4";
            BindData(category);
            Label2.Visible = false;
            TextBoxGrad.Visible = false;
            GraduationMonth.Visible = false;
            sd.Visible = true;
            ed.Visible = true;
            SearchButton.Visible = true;
            TextStartDate.Visible = true;
            TextEndDate.Visible = true;
        }

        protected void btnoverallQEA_Click(object sender, EventArgs e)
        {
            traineeStatusFlag.Value = "1";
            BindData("Overall");
            Label2.Visible = true;
            TextBoxGrad.Visible = true;
            GraduationMonth.Visible = true;
            sd.Visible = true;
            ed.Visible = true;
            SearchButton.Visible = true;
            TextStartDate.Visible = true;
            TextEndDate.Visible = true;
        }

        protected void GridViewQEA_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            int flag = int.Parse(traineeStatusFlag.Value);
            string cat = "";
            if (flag == 1)
            {
                cat = "Overall";
            }
            else if (flag == 2)
            {
                cat = "Intraining";
            }
            else if (flag == 3)
            {
                cat = "Graduated";
            }
            else if (flag == 4)
            {
                cat = "Resigned";
            }
            if (GradFlag.Value == "0" && SearchFlag.Value == "0")
            {
                BindData(cat);
                GridViewQEA.PageIndex = e.NewPageIndex;
                GridViewQEA.DataBind();
            }
            else if (GradFlag.Value == "1" && SearchFlag.Value == "0")
            {
                BindDataGrad(cat);

                GridViewQEA.PageIndex = e.NewPageIndex;
                GridViewQEA.DataBind();

            }
            else if (GradFlag.Value == "0" && SearchFlag.Value == "1")
            {
                BindDataSearch(cat);
                GridViewQEA.PageIndex = e.NewPageIndex;
                GridViewQEA.DataBind();

            }
        }

        protected void SearchButton_Click(object sender, EventArgs e)
        {
            SearchFlag.Value = "1";
            GradFlag.Value = "0";
            int flag = int.Parse(traineeStatusFlag.Value);
            if (flag == 1)
            {
                BindDataSearch("Overall");
            }
            else if (flag == 2)
            {
                BindDataSearch("Intraining");
            }
            else if (flag == 3)
            {
                BindDataSearch("Graduated");
            }
            else if (flag == 4)
            {
                BindDataSearch("Resigned");
            }
        }


        private void GetChartForDates(string category, string sd, string ed)
        {
            /*string cs = ConfigurationManager.ConnectionStrings["dbconstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("sp_Date_ChartData_BU_Vertical", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@category", category);
                cmd.Parameters.AddWithValue("@vertical", "QEA");
                cmd.Parameters.AddWithValue("@startpar", sd);
                cmd.Parameters.AddWithValue("@endpar", ed);

                Series series = ChartQEA.Series["Series1"];
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    series.Points.AddXY("InTraining", rdr["Intraining"].ToString());
                    series.Points.AddXY("Graduated", rdr["Graduated"].ToString());
                    series.Points.AddXY("Resigined", rdr["Resigned"].ToString());
                }
            }*/

            string cs = ConfigurationManager.ConnectionStrings["dbconstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("sp_Date_ChartData_BU_Vertical", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@category", category);
                cmd.Parameters.AddWithValue("@vertical", "QEA");
                cmd.Parameters.AddWithValue("@startpar", sd);
                cmd.Parameters.AddWithValue("@endpar", ed);
                Series series = ChartQEA.Series["Default"];
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                if (category == "Intraining")
                {
                    string[] xTrainValues = { "Intraining" };
                    int[] yTrainValues = new int[1];
                    while (rdr.Read())
                    {
                        int i = 0;
                        foreach (string s in xTrainValues)
                        {
                            yTrainValues[i] = (Int32)rdr[s];
                            i++;
                        }
                    }
                    ChartQEA.Series["Default"].Points.DataBindXY(xTrainValues, yTrainValues);
                    ChartQEA.Series["Default"].ChartType = SeriesChartType.Pie;
                    ChartQEA.Series["Default"]["PieLabelStyle"] = "Visible";
                    ChartQEA.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
                    ChartQEA.Legends[0].Enabled = true;
                }
                else if (category == "Graduated")
                {
                    string[] xGradValues = { "Graduated" };
                    int[] yGradValues = new int[1];
                    while (rdr.Read())
                    {
                        int i = 0;
                        foreach (string s in xGradValues)
                        {
                            yGradValues[i] = (Int32)rdr[s];
                            i++;
                        }
                    }
                    ChartQEA.Series["Default"].Points.DataBindXY(xGradValues, yGradValues);
                    ChartQEA.Series["Default"].ChartType = SeriesChartType.Pie;
                    ChartQEA.Series["Default"]["PieLabelStyle"] = "Visible";
                    ChartQEA.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
                    ChartQEA.Legends[0].Enabled = true;
                }
                else if (category == "Resigned")
                {
                    string[] xResValues = { "Resigned" };
                    int[] yResValues = new int[1];
                    while (rdr.Read())
                    {
                        int i = 0;
                        foreach (string s in xResValues)
                        {
                            yResValues[i] = (Int32)rdr[s];
                            i++;
                        }
                    }
                    ChartQEA.Series["Default"].Points.DataBindXY(xResValues, yResValues);
                    ChartQEA.Series["Default"].ChartType = SeriesChartType.Pie;
                    ChartQEA.Series["Default"]["PieLabelStyle"] = "Visible";
                    ChartQEA.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
                    ChartQEA.Legends[0].Enabled = true;
                }


                else
                {
                    string[] xValues = { "Intraining", "Graduated", "Resigned" };
                    int[] yValues = new int[3];
                    while (rdr.Read())
                    {
                        int i = 0;
                        foreach (string s in xValues)
                        {
                            yValues[i] = (Int32)rdr[s];
                            i++;
                        }
                    }
                    ChartQEA.Series["Default"].Points.DataBindXY(xValues, yValues);
                    ChartQEA.Series["Default"].ChartType = SeriesChartType.Pie;
                    ChartQEA.Series["Default"]["PieLabelStyle"] = "Visible";
                    ChartQEA.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
                    ChartQEA.Legends[0].Enabled = true;
                }
            }




        }

        protected void BULog_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin_BU.aspx");
        }


        private void BindDataGrad(string parm)
        {
            string graduation = TextBoxGrad.Text.ToString();
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand commandToExecute = new SqlCommand("BU_Grad_data", con);
                commandToExecute.Parameters.AddWithValue("@category", parm);
                commandToExecute.Parameters.AddWithValue("@vertical", "QEA");
                commandToExecute.Parameters.AddWithValue("@date", DateTime.Parse(graduation));

                SqlDataAdapter da = new SqlDataAdapter(commandToExecute);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewQEA.DataSource = ds;
                GridViewQEA.DataBind();
                GetChartForGrad(parm, graduation);
            }
        }


        private void BindDataSearch(string param)
        {
            string sd = TextStartDate.Text;
            string ed = TextEndDate.Text;
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand commandToExecute = new SqlCommand("sp_BU_EmployeeDetails_SearchData", con);
                commandToExecute.Parameters.AddWithValue("@category", param);
                commandToExecute.Parameters.AddWithValue("@vertical", "QEA");
                commandToExecute.Parameters.AddWithValue("@start", DateTime.Parse(sd));
                commandToExecute.Parameters.AddWithValue("@end", DateTime.Parse(ed));
                SqlDataAdapter da = new SqlDataAdapter(commandToExecute);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataSet ds = new DataSet();
                da.Fill(ds);

                GridViewQEA.DataSource = ds;
                GridViewQEA.DataBind();
                GetChartForDates(param, sd, ed);

            }
        }

        protected void GraduationMonth_Click(object sender, EventArgs e)
        {
            GradFlag.Value = "1";
            SearchFlag.Value = "0";
            //GridViewacademy.Visible = false;
            int searchflag = int.Parse(traineeStatusFlag.Value);
            if (searchflag == 1)
            {
                BindDataGrad("Overall");
            }
            else if (searchflag == 2)
            {
                BindDataGrad("Intraining");
            }
            else if (searchflag == 3)
            {
                BindDataGrad("Graduated");
            }
        }

        protected void DS_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Demand_Supply.aspx");
        }

        protected void Cons_Click(object sender, EventArgs e)
        {
            Consolidate();
            ConsolidateChart();
            sd.Visible = false;
            ed.Visible = false;
            SearchButton.Visible = false;
            TextStartDate.Visible = false;
            TextEndDate.Visible = false;
            GraduationMonth.Visible = false;
            TextBoxGrad.Visible = false;
            Label2.Visible = false;
        }

        private void ConsolidateChart()
        {

            string query = string.Format("select distinct track,count(associateId) as Count from tabEmployeeDetails where trainingVertical='QEA' group by track");
            DataTable dt = GetData(query);
            ChartQEA.DataSource = dt;
            ChartQEA.Series[0].ChartType = SeriesChartType.RangeBar;
            ChartQEA.Legends[0].Enabled = true;
            ChartQEA.Series[0].XValueMember = "track";
            ChartQEA.Series[0].YValueMembers = "Count";
            //ChartQEA.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
            ChartQEA.DataBind();




        }

        private void Consolidate()
        {
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand commandToExecute = new SqlCommand("Consolidate", con);
                commandToExecute.Parameters.AddWithValue("@vertical", "QEA");
                SqlDataAdapter da = new SqlDataAdapter(commandToExecute);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewQEA.DataSource = ds;
                GridViewQEA.DataBind();
            }
        }





        private static DataTable GetData(string query)
        {
            string constr = ConfigurationManager.ConnectionStrings["dbconstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    DataTable dt = new DataTable();
                    using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
                    {
                        sda.Fill(dt);
                    }

                    return dt;
                }
            }
        }

        protected void H1_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/H1_Analysis.aspx");
        }
    }
    }
