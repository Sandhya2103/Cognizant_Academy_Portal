


SELECT 
	name
FROM 
   sys.procedures 
WHERE 
   name LIKE '%Employee%'

   SELECT
    ROUTINE_NAME, 
    ROUTINE_DEFINITION , 
    ROUTINE_SCHEMA
FROM
    INFORMATION_SCHEMA.ROUTINES 
WHERE
    ROUTINE_TYPE='PROCEDURE' AND
    ROUTINE_NAME LIKE '%chart%'




--NEW PROC





--END


select * from tabLogin


CREATE procedure spBULogin
@userId varchar(6),
@pass varchar(20)

as

begin
DECLARE @ResultValue varchar,
 @output varchar

set  @ResultValue  = (SELECT BU
                    FROM tabLogin 
                    WHERE userId=@userId and pass=@pass );

    if (@ResultValue='AVM')
	begin
	set @output=1
	return @output
	end

	else if (@ResultValue='CDB')
	begin
	set @output=2
	return @output
	end

	else if(@ResultValue='IS')
	begin
	set @output=3
	return @output
	end

	else if(@ResultValue='QEA')
	begin
	set @output=4
	return @output
	end

	else 
	begin
	set @output=0
	return @output
	end


end

---AVM



create procedure spBULoginIS
@userId varchar(6),
@pass varchar(20)

as
begin
select * from tabLogin where userId=@userId and pass=@pass and BU='IS'
end

EXEC spBULoginIS '761001','12345'


drop procedure spMainAdminLogin_New



CREATE procedure spMainAdminLogin_New
(
@MainAdminID varchar(6),
@MainAdminpass varchar(20)
)
as 
begin
Declare @AccountLocked bit
 Declare @Count int
 Declare @RetryCount int

declare @bu varchar(20)
declare @returnValue varchar(20)

Select @AccountLocked = IsLocked from tabLogin where userId =@MainAdminID 

 if(@AccountLocked = 1)
 Begin
  Select 1 as AccountLocked, 0 as Authenticated, 0 as RetryAttempts
 End
 Else
 Begin
  -- Check if the username and password match
  Select @Count = COUNT(userId) from tabLogin
  where userId = @MainAdminID and pass = @MainAdminpass
  
  -- If match found
  if(@Count = 1)
  Begin
   -- Reset RetryAttempts 
   Update tabLogin set RetryAttempts = 0
   where userId = @MainAdminID

   select @bu = BU from tabLogin where userId=@MainAdminID and pass=@MainAdminpass
   if(@bu ='MainAdmin') begin
    set @returnValue='Main Admin' 
   Select @returnValue as BU, 0 as AccountLocked, 1 as Authenticated, 0 as RetryAttempts
    end

    else  if(@bu ='academy') begin  set @returnValue='Academy'
	 Select @returnValue as BU, 0 as AccountLocked, 1 as Authenticated, 0 as RetryAttempts 
	 end

    else if(@bu ='AVM') begin  set @returnValue='AVM'
	 Select @returnValue as BU, 0 as AccountLocked, 1 as Authenticated, 0 as RetryAttempts end

     else if(@bu ='CDB') begin set @returnValue='CDB'
	  Select @returnValue as BU, 0 as AccountLocked, 1 as Authenticated, 0 as RetryAttempts end

     else if(@bu ='QEA') begin set @returnValue='QEA'
	  Select @returnValue as BU, 0 as AccountLocked, 1 as Authenticated, 0 as RetryAttempts end

	  else if(@bu ='IS') begin set @returnValue='IS'
	  Select @returnValue as BU, 0 as AccountLocked, 1 as Authenticated, 0 as RetryAttempts end

	  Else
  Begin
 
   -- If a match is not found
   Select  @RetryCount = RetryAttempts
   from tabLogin
   where userId = @MainAdminID
   
   Set @RetryCount = @RetryCount + 1
   
   if(@RetryCount <= 3)
   Begin
    -- If re-try attempts are not completed
    Update tabLogin set RetryAttempts = @RetryCount
    where userId = @MainAdminID 
    
    Select 0 as AccountLocked, 0 as Authenticated, @RetryCount as RetryAttempts
   End
   Else
   Begin
    -- If re-try attempts are completed
    Update tabLogin set RetryAttempts = @RetryCount,
    IsLocked = 1, LockedDateTime = GETDATE()
    where userId = @MainAdminID

    Select 1 as AccountLocked, 0 as Authenticated, 0 as RetryAttempts
   End
  End
 End
End   End


