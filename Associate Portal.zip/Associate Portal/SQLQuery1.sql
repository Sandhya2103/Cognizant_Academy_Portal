sp_helptext sp_ChartData_Academy 'Resigned'
go

alter procedure sp_ChartData_Academy
(
@category varchar(20)
)
as
begin
declare @headCountAVM int
declare @headCountCDB int
declare @headCountQEA int

if @category='Overall'
begin
select @headCountAVM = count(associateId) from tabEmployeeDetails where trainingVertical='AVM' 
select @headCountCDB =  count(associateId) from tabEmployeeDetails where trainingVertical='CDB'
select @headCountQEA = count(associateId) from tabEmployeeDetails where trainingVertical='QEA'

end

else if @category='Graduated'
begin
select @headCountAVM = count(associateId) from tabEmployeeDetails where trainingVertical='AVM' and traineeStatus='Graduated'
select @headCountCDB = count(associateId) from tabEmployeeDetails where trainingVertical='CDB' and traineeStatus='Graduated'
select @headCountQEA = count(associateId) from tabEmployeeDetails where trainingVertical='QEA' and traineeStatus='Graduated'
end

else if @category='Training'
begin
select @headCountAVM = count(associateId) from tabEmployeeDetails where trainingVertical='AVM' and traineeStatus='Intraining'
select @headCountCDB = count(associateId) from tabEmployeeDetails where trainingVertical='CDB' and traineeStatus='Intraining'
select @headCountQEA = count(associateId) from tabEmployeeDetails where trainingVertical='QEA' and traineeStatus='Intraining'
end

else if @category='Resigned'
begin
select @headCountAVM = count(associateId) from tabEmployeeDetails where trainingVertical='AVM' and traineeStatus='Resigned'
select @headCountCDB = count(associateId) from tabEmployeeDetails where trainingVertical='CDB' and traineeStatus='Resigned'
select @headCountQEA = count(associateId) from tabEmployeeDetails where trainingVertical='QEA' and traineeStatus='Resigned'
end



select @headCountAVM as 'AVM', @headCountCDB as 'CDB', @headCountQEA as 'QEA'
end

--===procedure END

declare @category varchar(20)
set @category='Graduated'
select trainingVertical,count(associateid)
 from tabEmployeeDetails where traineeStatus=@category 
 group by trainingVertical
 go

 select traineeStatus,
  count(associateid) from tabEmployeeDetails
 group by traineeStatus


 CREATE procedure [dbo].[sp_Academy_EmployeeDetails_Updated_1]

as 
begin

select location as Location,batchCode as 'Batch Code',batchOwnerName as 'BatchOwner Name', track as Track,batchStartDate as 'Batch Start Date',plannedGraduationDate as 'Planned Graduation Date',
monthOfGraduation as 'Month Of Graduation',actualGraduationDate as 'Actual Graduation Date',reasonForExtension as 'Reason For Extension',traineeStatus as 'Trainee Status',
trainingVertical as 'Training Vertical',intakeMonth as 'Intake Month',dateOfJoining as DOJ,associateName as 'Associate Name',collegeName as 'College Name',qualification as 'Qualification',
branch as Branch,designation as Designation from tabEmployeeDetails where traineeStatus='overall';

end

---end

CREATE procedure [dbo].[sp_Academy_EmployeeDetails_Updated]
(
 @category  varchar(20)
)
as 
begin


select location as Location,batchCode as 'Batch Code',batchOwnerName as 'BatchOwner Name', track as Track,batchStartDate as 'Batch Start Date',plannedGraduationDate as 'Planned Graduation Date',
monthOfGraduation as 'Month Of Graduation',actualGraduationDate as 'Actual Graduation Date',reasonForExtension as 'Reason For Extension',traineeStatus as 'Trainee Status',
trainingVertical as 'Training Vertical',intakeMonth as 'Intake Month',dateOfJoining as DOJ,associateName as 'Associate Name',collegeName as 'College Name',qualification as 'Qualification',
branch as Branch,designation as Designation from tabEmployeeDetails where traineeStatus=@category;

end

Exec [dbo].[sp_Academy_EmployeeDetails_Updated] 'Intraining'


--bindata proc


CREATE procedure sp_fetch_data
(
@category varchar(20)
)
as
begin

if @category='Overall'
begin
select location as Location,batchCode as 'Batch Code',batchOwnerName as 'BatchOwner Name', track as Track,batchStartDate as 'Batch Start Date',plannedGraduationDate as 'Planned Graduation Date',
monthOfGraduation as 'Month Of Graduation',actualGraduationDate as 'Actual Graduation Date',reasonForExtension as 'Reason For Extension',traineeStatus as 'Trainee Status',
trainingVertical as 'Training Vertical',intakeMonth as 'Intake Month',dateOfJoining as DOJ,associateName as 'Associate Name',collegeName as 'College Name',qualification as 'Qualification',
branch as Branch,designation as Designation from tabEmployeeDetails;

end

else if @category='Graduated'
begin
select location as Location,batchCode as 'Batch Code',batchOwnerName as 'BatchOwner Name', track as Track,batchStartDate as 'Batch Start Date',plannedGraduationDate as 'Planned Graduation Date',
monthOfGraduation as 'Month Of Graduation',actualGraduationDate as 'Actual Graduation Date',reasonForExtension as 'Reason For Extension',traineeStatus as 'Trainee Status',
trainingVertical as 'Training Vertical',intakeMonth as 'Intake Month',dateOfJoining as DOJ,associateName as 'Associate Name',collegeName as 'College Name',qualification as 'Qualification',
branch as Branch,designation as Designation from tabEmployeeDetails where traineeStatus='Graduated';

end

else if @category='Training'
begin
select location as Location,batchCode as 'Batch Code',batchOwnerName as 'BatchOwner Name', track as Track,batchStartDate as 'Batch Start Date',plannedGraduationDate as 'Planned Graduation Date',
monthOfGraduation as 'Month Of Graduation',actualGraduationDate as 'Actual Graduation Date',reasonForExtension as 'Reason For Extension',traineeStatus as 'Trainee Status',
trainingVertical as 'Training Vertical',intakeMonth as 'Intake Month',dateOfJoining as DOJ,associateName as 'Associate Name',collegeName as 'College Name',qualification as 'Qualification',
branch as Branch,designation as Designation from tabEmployeeDetails where traineeStatus='Intraining';

end

else if @category='Resigned'
begin
select location as Location,batchCode as 'Batch Code',batchOwnerName as 'BatchOwner Name', track as Track,batchStartDate as 'Batch Start Date',plannedGraduationDate as 'Planned Graduation Date',
monthOfGraduation as 'Month Of Graduation',actualGraduationDate as 'Actual Graduation Date',reasonForExtension as 'Reason For Extension',traineeStatus as 'Trainee Status',
trainingVertical as 'Training Vertical',intakeMonth as 'Intake Month',dateOfJoining as DOJ,associateName as 'Associate Name',collegeName as 'College Name',qualification as 'Qualification',
branch as Branch,designation as Designation from tabEmployeeDetails where traineeStatus='Resigned';

end

end


--NEW CHART WITH DATE
drop procedure sp_Date_ChartData_Academy 

CREATE procedure sp_Date_ChartData_Academy 
(
@category varchar(20),
@start varchar(20),
@end varchar(20)

)
as
begin
declare @headCountAVM int
declare @headCountCDB int
declare @headCountQEA int
--declare @start  date 
--declare @end date 

--select @start = Convert(date,@startpar,101)
--select @end = Convert(date,@endpar,101)

if @category='Overall'
begin
select @headCountAVM = count(associateId) from tabEmployeeDetails where trainingVertical='AVM' and batchStartDate between @start and @end
select @headCountCDB =  count(associateId) from tabEmployeeDetails where trainingVertical='CDB' and batchStartDate between @start and @end
select @headCountQEA = count(associateId) from tabEmployeeDetails where trainingVertical='QEA' and batchStartDate between @start and @end

end

else if @category='Graduated'
begin
select @headCountAVM = count(associateId) from tabEmployeeDetails where trainingVertical='AVM' and traineeStatus='Graduated' and batchStartDate between @start and @end
select @headCountCDB = count(associateId) from tabEmployeeDetails where trainingVertical='CDB' and traineeStatus='Graduated' and batchStartDate between @start and @end
select @headCountQEA = count(associateId) from tabEmployeeDetails where trainingVertical='QEA' and traineeStatus='Graduated' and batchStartDate between @start and @end
end

else if @category='Training'
begin
select @headCountAVM = count(associateId) from tabEmployeeDetails where trainingVertical='AVM' and traineeStatus='Intraining' and batchStartDate between @start and @end
select @headCountCDB = count(associateId) from tabEmployeeDetails where trainingVertical='CDB' and traineeStatus='Intraining' and batchStartDate between @start and @end
select @headCountQEA = count(associateId) from tabEmployeeDetails where trainingVertical='QEA' and traineeStatus='Intraining' and batchStartDate between @start and @end
end

else if @category='Resigned'
begin
select @headCountAVM = count(associateId) from tabEmployeeDetails where trainingVertical='AVM' and traineeStatus='Resigned' and batchStartDate between @start and @end
select @headCountCDB = count(associateId) from tabEmployeeDetails where trainingVertical='CDB' and traineeStatus='Resigned' and batchStartDate between @start and @end
select @headCountQEA = count(associateId) from tabEmployeeDetails where trainingVertical='QEA' and traineeStatus='Resigned' and batchStartDate between @start and @end
end



select @headCountAVM as 'AVM', @headCountCDB as 'CDB', @headCountQEA as 'QEA'
end


--END

DECLARE @myVar varchar(20)
SET @myVar = '12/01/2019'
SELECT  SQL_VARIANT_PROPERTY(Convert(date,@myVar,101),'BaseType') BaseType;

SELECT SQL_VARIANT_PROPERTY(con,'BaseType') BaseType
select SQL_VARIANT_PROPERTY(Convert(varchar(30),'12/01/2019',101),'Base Type') BaseType;