CREATE table tabLogin
(
userId int primary key identity(760000,1),
pass varchar(20),
BU varchar(20),
subTrack VARCHAR(150),
category varchar(20)
)


create table tabEmployeeDetails
(
location varchar(20),
batchCode varchar(30),
batchOwnerName varchar(100),
track varchar(100),
batchStartDate date,
plannedGraduationDate date,
monthOfGraduation varchar(10),
actualGraduationDate varchar(20),
reasonForExtension varchar(500),
traineeStatus varchar(20),
trainingVertical varchar(50),
intakeMonth varchar(20),
dateOfJoining date,
associateId int primary key identity(761000,1),
associateName varchar(50),
collegeName varchar(100),
qualification varchar(20),
branch varchar(30),
designation varchar(20)
)


select * from tabLogin

insert into tabLogin(pass,BU,subTrack,category) values (12345,'academy','null','admin')
insert into tabLogin(pass,BU,subTrack,category) values (12345,'AVM','null','admin')
insert into tabLogin(pass,BU,subTrack,category) values (12345,'CDB','null','admin')
insert into tabLogin(pass,BU,subTrack,category) values (12345,'QEA','null','admin')
insert into tabLogin(pass,BU,subTrack,category) values (12345,'AVM','main','subAdmin')
insert into tabLogin(pass,BU,subTrack,category) values (12345,'AVM','EAS Oracle','subAdmin')
insert into tabLogin(pass,BU,subTrack,category) values (12345,'AVM','AIM','subAdmin')
insert into tabLogin(pass,BU,subTrack,category) values (12345,'AVM','EAS','subAdmin')
insert into tabLogin(pass,BU,subTrack,category) values (12345,'AVM','EAS Internal','subAdmin')
insert into tabLogin(pass,BU,subTrack,category) values (12345,'AVM','EAS IPM','subAdmin')
insert into tabLogin(pass,BU,subTrack,category) values (12345,'AVM','EAS SAP','subAdmin')

insert into tabLogin(pass,BU,subTrack,category) values (12345,'CDB','IPS','subAdmin')
insert into tabLogin(pass,BU,subTrack,category) values (12345,'CDB','IPS Commercial Solutions','subAdmin')
insert into tabLogin(pass,BU,subTrack,category) values (12345,'CDB','Interactive','subAdmin')
insert into tabLogin(pass,BU,subTrack,category) values (12345,'CDB','INT_DGTExp_OFF_PDP_Eng','subAdmin')
insert into tabLogin(pass,BU,subTrack,category) values (12345,'CDB','INT-T-DigitalChanel-Collab','subAdmin')







INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM001','A,KiramMayee','AVM_ISMO_PT_Extension','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Praveen','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM001','A,KiramMayee','AVM_ISMO_PT_Extension','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Shafi','Kumaraguru College of Technology','BE','Civil','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM001','A,KiramMayee','AVM_ISMO_PT_Extension','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Rohit','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM001','A,KiramMayee','AVM_ISMO_PT_Extension','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Vishveshraj','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM001','A,KiramMayee','AVM_ISMO_PT_Extension','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Manoj Kumar','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM001','A,KiramMayee','AVM_ISMO_PT_Extension','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Megesh Kumar','Kumaraguru College of Technology','BE','Automobile','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM001','A,KiramMayee','AVM_ISMO_PT_Extension','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Naveen','PSG College of Technology','BE','EIE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM001','A,KiramMayee','AVM_ISMO_PT_Extension','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Aakash','PSG College of Technology','BE','EIE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM001','A,KiramMayee','AVM_ISMO_PT_Extension','04/08/2019','04/26/2019','Apr','','','Resigned','AVM','Apr 2019','04/08/2019','Kishore Kumar','Karpagam College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM001','A,KiramMayee','AVM_ISMO_PT_Extension','04/08/2019','04/26/2019','Apr','','','Resigned','AVM','Apr 2019','04/08/2019','Ram Kumar','Karpagam College of Technology','BE','EEE','PAT')

=======================================================================================================================================================================================================================================================================

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM002','A,KiramMayee','GenC_Dotnet_AD_Server','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Suresh Kumar','Karpagam College of Technology','BE','BT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM002','A,KiramMayee','GenC_Dotnet_AD_Server','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Ramesh Kumar','Karpagam College of Technology','BE','BT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM002','A,KiramMayee','GenC_Dotnet_AD_Server','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Mangalya Kumar','Kumaraguru College of Technology','BE','Civil','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM002','A,KiramMayee','GenC_Dotnet_AD_Server','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Naresh','Krishna College of Technology','BE','FT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM002','A,KiramMayee','GenC_Dotnet_AD_Server','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Bharanesh','Krishna College of Technology','BE','FT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM002','A,KiramMayee','GenC_Dotnet_AD_Server','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Sumesh','Krishna College of Technology','BE','Mechanical','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM002','A,KiramMayee','GenC_Dotnet_AD_Server','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Mahath','Kumaraguru College of Technology','BE','IT','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM002','A,KiramMayee','GenC_Dotnet_AD_Server','04/08/2019','04/26/2019','Apr','','','Resigned','AVM','Apr 2019','04/08/2019','Yashika','SNS College of Technology','BE','FT','PAT')

=====================================================================================================================================================================================================================================================================================


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM003','A,KiramMayee','GTP_AVM-DW-Informatica Oracle','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Ujala','United College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM003','A,KiramMayee','GTP_AVM-DW-Informatica Oracle','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Dharma','Inspired College of Technology','BE','Civil','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM003','A,KiramMayee','GTP_AVM-DW-Informatica Oracle','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Varma','Confident College of Technology','BE','Mechanical','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM003','A,KiramMayee','GTP_AVM-DW-Informatica Oracle','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Ajanta','United College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM003','A,KiramMayee','GTP_AVM-DW-Informatica Oracle','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Karnataki','United College of Technology','BE','FT','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM003','A,KiramMayee','GTP_AVM-DW-Informatica Oracle','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Hannah','Confident College of Technology','BE','EIE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM003','A,KiramMayee','GTP_AVM-DW-Informatica Oracle','04/08/2019','04/26/2019','Apr','','','Resigned','AVM','Apr 2019','04/08/2019','Emma','Inspired College of Technology','BE','FT','PAT')

=============================================================================================================================================================================================================================================================================
4

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM001','A,Vigneshvaran','GTP_AVM_eBiz_AppsDBA','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Manjula','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM001','A,Vigneshvaran','GTP_AVM_eBiz_AppsDBA','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Shafika','Kumaraguru College of Technology','BE','Civil','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM001','A,Vigneshvaran','GTP_AVM_eBiz_AppsDBA','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Rohitha','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM001','A,Vigneshvaran','GTP_AVM_eBiz_AppsDBA','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Vishveshrajeshvari','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM001','A,Vigneshvaran','GTP_AVM_eBiz_AppsDBA','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Manoja Kumari','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM001','A,Vigneshvaran','GTP_AVM_eBiz_AppsDBA','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Megeshi Kumari','Kumaraguru College of Technology','BE','Automobile','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM001','A,Vigneshvaran','GTP_AVM_eBiz_AppsDBA','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Naveena','PSG College of Technology','BE','EIE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM001','A,Vigneshvaran','GTP_AVM_eBiz_AppsDBA','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Aakashi','PSG College of Technology','BE','EIE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM001','A,Vigneshvaran','GTP_AVM_eBiz_AppsDBA','04/08/2019','04/26/2019','Apr','','','Resigned','AVM','Apr 2019','04/08/2019','Kish Kumari','Karpagam College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM001','A,Vigneshvaran','GTP_AVM_eBiz_AppsDBA','04/08/2019','04/26/2019','Apr','','','Resigned','AVM','Apr 2019','04/08/2019','Ram Kumari','Karpagam College of Technology','BE','EEE','PAT')

============================================================================================================================================================================================================================================================================
5
INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Sureshi Kumari','Karpagam College of Technology','BE','BT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Rameshi Kumari','Karpagam College of Technology','BE','BT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM','Apr 2019','04/08/2019','Mangalya Kumari','Kumaraguru College of Technology','BE','Civil','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Nareshi','Krishna College of Technology','BE','FT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Bharat','Krishna College of Technology','BE','FT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Sumesha','Krishna College of Technology','BE','Mechanical','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/08/2019','04/26/2019','Apr','','','Intraining','AVM','Apr 2019','04/08/2019','Mahathi','Kumaraguru College of Technology','BE','IT','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/08/2019','04/26/2019','Apr','','','Resigned','AVM','Apr 2019','04/08/2019','Yashik','SNS College of Technology','BE','FT','PAT')
=================================================================================================================================================================================================================================================================================
6

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19AVM003','A,rahul','GTP_EAS-AVM-OSP-Peoplesoft','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM EAS Oracle','Apr 2019','04/08/2019','Malarvannan','karmugil College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19AVM003','A,rahul','GTP_EAS-AVM-OSP-Peoplesoft','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM EAS Oracle','Apr 2019','04/08/2019','Emma','karmugil College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19AVM003','A,rahul','GTP_EAS-AVM-OSP-Peoplesoft','04/08/2019','04/26/2019','Apr','','','Intraining','AVM EAS Oracle','Apr 2019','04/08/2019','Ashok','Sun College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19AVM003','A,rahul','GTP_EAS-AVM-OSP-Peoplesoft','04/08/2019','04/26/2019','Apr','','','Intraining','AVM EAS Oracle','Apr 2019','04/08/2019','Vikas','Sun College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19AVM003','A,rahul','GTP_EAS-AVM-OSP-Peoplesoft','04/08/2019','04/26/2019','Apr','','','Intraining','AVM EAS Oracle','Apr 2019','04/08/2019','Vishmitha','Varnam College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19AVM003','A,rahul','GTP_EAS-AVM-OSP-Peoplesoft','04/08/2019','04/26/2019','Apr','','','Intraining','AVM EAS Oracle','Apr 2019','04/08/2019','Vinu','Sun College of Technology','BE','BT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19AVM003','A,rahul','GTP_EAS-AVM-OSP-Peoplesoft','04/08/2019','04/26/2019','Apr','','','Intraining','AVM EAS Oracle','Apr 2019','04/08/2019','Ashokini','Sun College of Technology','BE','EEE','PAT')
INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19AVM003','A,rahul','GTP_EAS-AVM-OSP-Peoplesoft','04/08/2019','04/26/2019','Apr','','','Intraining','AVM EAS Oracle','Apr 2019','04/08/2019','Malar','Sun College of Technology','BE','EEE','PAT')
INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19AVM003','A,rahul','GTP_EAS-AVM-OSP-Peoplesoft','04/08/2019','04/26/2019','Apr','','','Intraining','AVM EAS Oracle','Apr 2019','04/08/2019','Thiru','Moon College of Technology','BE','EEE','PAT')

====================================================================================================================================================================================================================================================================================

delete from tabEmployeeDetails where batchOwnerName='Narmada'
====================================================================================================================================================================================================================================================================================
7
INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM-AIM','Apr 2019','04/08/2019','Malarvannan','kandha College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM-AIM','Apr 2019','04/08/2019','Malar kannagi','kandha College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','AVM-AIM','Apr 2019','04/08/2019','Manikam','Hosur College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/08/2019','04/26/2019','Apr','','','Intraining','AVM-AIM','Apr 2019','04/08/2019','Manikandan','Santhi College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/08/2019','04/26/2019','Apr','','','Intraining','AVM-AIM','Apr 2019','04/08/2019','Malar','Santhi College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/08/2019','04/26/2019','Apr','','','Intraining','AVM-AIM','Apr 2019','04/08/2019','Shreyas','kumaraguru College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/08/2019','04/26/2019','Apr','','','Intraining','AVM-AIM','Apr 2019','04/08/2019','Harish','Santhi College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/08/2019','04/26/2019','Apr','','','Intraining','AVM-AIM','Apr 2019','04/08/2019','Sujin','Veera College of Technology','BE','Mech','PAT')



INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/08/2019','04/26/2019','Apr','','','Intraining','AVM-AIM','Apr 2019','04/08/2019','Vasuki','Santhi College of Technology','BE','Civil','PAT')

===========================================================================================================================================================================================================================================================================

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA101','A,rahul','GTP_Automation Fast track_Selenium testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Suresh Kumar','kolar College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA101','A,rahul','GTP_Automation Fast track_Selenium testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Varun','krishna College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA101','A,rahul','GTP_Automation Fast track_Selenium testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Mahesh','PSG College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA101','A,rahul','GTP_Automation Fast track_Selenium testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Sonakshi','kumaraguru College of Technology','BE','Civil','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA101','A,rahul','GTP_Automation Fast track_Selenium testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Watson','Sulthan College of Technology','BE','IT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA101','A,rahul','GTP_Automation Fast track_Selenium testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Praneeth','kolar College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA101','A,rahul','GTP_Automation Fast track_Selenium testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Praneetha','Varnam College of Technology','BE','Civil','PAT')
INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA101','A,rahul','GTP_Automation Fast track_Selenium testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Prani','Varnam College of Technology','BE','Civil','PAT')



==============================================================================================

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA102','A,rahul','GTP_Automation Selenium Testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Malarvannan','kandha College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA102','A,rahul','GTP_Automation Selenium Testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Malar kannagi','kandha College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA102','A,rahul','GTP_Automation Selenium Testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Manikam','Hosur College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA102','A,rahul','GTP_Automation Selenium Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Manikandan','Santhi College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA102','A,rahul','GTP_Automation Selenium Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Malar','Santhi College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA102','A,rahul','GTP_Automation Selenium Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Shreyas','kumaraguru College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA102','A,rahul','GTP_Automation Selenium Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Harish','Santhi College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA102','A,rahul','GTP_Automation Selenium Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Sujin','Veera College of Technology','BE','Mech','PAT')



INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA102','A,rahul','GTP_Automation Selenium Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Vasuki','Santhi College of Technology','BE','Civil','PAT')


=========================================================================================================

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA103','A,rahul','GTP_Automation SOAP UI Testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Malarvannan','karmugil College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA103','A,rahul','GTP_Automation SOAP UI Testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Emma','karmugil College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA103','A,rahul','GTP_Automation SOAP UI Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Ashok','Sun College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA103','A,rahul','GTP_Automation SOAP UI Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Vikas','Sun College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA103','A,rahul','GTP_Automation SOAP UI Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Vishmitha','Varnam College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA103','A,rahul','GTP_Automation SOAP UI Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Vinu','Sun College of Technology','BE','BT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA103','A,rahul','GTP_Automation SOAP UI Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Ashokini','Sun College of Technology','BE','EEE','PAT')
INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA103','A,rahul','GTP_Automation SOAP UI Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Malar','Sun College of Technology','BE','EEE','PAT')
INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA103','A,rahul','GTP_Automation SOAP UI Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Thiru','Moon College of Technology','BE','EEE','PAT')

================================================================================================================

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19QEA101','A,Vigneshvaran','GTP_Automation UFT Testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Sureshi Kumari','Karpagam College of Technology','BE','BT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19QEA101','A,Vigneshvaran','GTP_Automation UFT Testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Rameshi Kumari','Karpagam College of Technology','BE','BT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19QEA101','A,Vigneshvaran','GTP_Automation UFT Testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Mangalya Kumari','Kumaraguru College of Technology','BE','Civil','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19QEA101','A,Vigneshvaran','GTP_Automation UFT Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Nareshi','Krishna College of Technology','BE','FT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19QEA101','A,Vigneshvaran','GTP_Automation UFT Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Bharat','Krishna College of Technology','BE','FT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19QEA101','A,Vigneshvaran','GTP_Automation UFT Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Sumesha','Krishna College of Technology','BE','Mechanical','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19QEA101','A,Vigneshvaran','GTP_Automation UFT Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Mahathi','Kumaraguru College of Technology','BE','IT','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19QEA101','A,Vigneshvaran','GTP_Automation UFT Testing','04/08/2019','04/26/2019','Apr','','','Resigned','QEA','Apr 2019','04/08/2019','Yashik','SNS College of Technology','BE','FT','PAT')

===========================================================================================================================




INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Manjula','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Shafika','Kumaraguru College of Technology','BE','Civil','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Rohitha','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','04/08/2019','04/26/2019','Apr','05/09/2019','','Graduated','QEA','Apr 2019','04/08/2019','Vishveshrajeshvari','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Manoja Kumari','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Megeshi Kumari','Kumaraguru College of Technology','BE','Automobile','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Naveena','PSG College of Technology','BE','EIE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','04/08/2019','04/26/2019','Apr','','','Intraining','QEA','Apr 2019','04/08/2019','Aakashi','PSG College of Technology','BE','EIE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','04/08/2019','04/26/2019','Apr','','','Resigned','QEA','Apr 2019','04/08/2019','Kish Kumari','Karpagam College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','04/08/2019','04/26/2019','Apr','','','Resigned','QEA','Apr 2019','04/08/2019','Ram Kumari','Karpagam College of Technology','BE','EEE','PAT')



=======================================================================================================================================================================================================================================================================
--2018 apr to may

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19QEA103','A,rahul','GTP_Automation SOAP UI Testing','04/09/2018','05/28/2018','May','','','Intraining','QEA','Apr 2018','04/09/2018','Thiru','Moon College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM003','A,KiramMayee','GTP_AVM-DW-Informatica Oracle','04/09/2018','05/28/2018','May','05/28/2018','','Graduated','AVM','Apr 2018','04/09/2018','Ujala','United College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM003','A,KiramMayee','GTP_AVM-DW-Informatica Oracle','04/09/2018','05/28/2018','May','05/28/2018','','Graduated','AVM','Apr 2019','04/09/2018','Dharma','Inspired College of Technology','BE','Civil','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM003','A,KiramMayee','GTP_AVM-DW-Informatica Oracle','04/09/2018','05/28/2018','May','05/09/2019','','Graduated','AVM','Apr 2019','04/09/2018','Varma','Confident College of Technology','BE','Mechanical','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM003','A,KiramMayee','GTP_AVM-DW-Informatica Oracle','04/09/2018','05/28/2018','May','05/28/2018','','Graduated','AVM','Apr 2019','04/09/2018','Ajanta','United College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM003','A,KiramMayee','GTP_AVM-DW-Informatica Oracle','04/09/2018','05/28/2018','May','','','Intraining','AVM','Apr 2019','04/09/2018','Karnataki','United College of Technology','BE','FT','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM003','A,KiramMayee','GTP_AVM-DW-Informatica Oracle','04/09/2018','05/28/2018','May','','','Intraining','AVM','Apr 2019','04/09/2018','Hannah','Confident College of Technology','BE','EIE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Chennai','CHN19AVM003','A,KiramMayee','GTP_AVM-DW-Informatica Oracle','04/09/2018','05/28/2018','May','','','Resigned','AVM','Apr 2019','04/09/2018','Emma','Inspired College of Technology','BE','FT','PAT')


=======================================================================================================================================================================================================================================================================
--2018 apr to may

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/09/2018','05/28/2018','May','05/28/2018','','Graduated','AVM','Apr 2018','04/09/2018','Sureshi Kumari','Karpagam College of Technology','BE','BT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/09/2018','05/28/2018','May','05/28/2018','','Graduated','AVM','Apr 2018','04/09/2018','Rameshi Kumari','Karpagam College of Technology','BE','BT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/09/2018','05/28/2018','May','05/28/2018','','Graduated','AVM','Apr 2018','04/09/2018','Mangalya Kumari','Kumaraguru College of Technology','BE','Civil','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/09/2018','05/28/2018','May','','','Intraining','AVM','Apr 2018','04/09/2018','Nareshi','Krishna College of Technology','BE','FT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/09/2018','05/28/2018','May','','','Intraining','AVM','Apr 2018','04/09/2018','Bharat','Krishna College of Technology','BE','FT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/09/2018','05/28/2018','May','','','Intraining','AVM','Apr 2018','04/09/2018','Sumesha','Krishna College of Technology','BE','Mechanical','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/09/2018','05/28/2018','May','','','Intraining','AVM','Apr 2018','04/09/2018','Mahathi','Kumaraguru College of Technology','BE','IT','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','04/09/2018','05/28/2018','May','','','Resigned','AVM','Apr 2018','04/09/2018','Yashik','SNS College of Technology','BE','FT','PAT')



========================================================================================================================================================================================================================================================================

--2018 feb to april

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','02/05/2018','04/06/2018','Apr','04/06/2018','','Graduated','QEA','Feb 2018','02/05/2018','Manjula','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','02/05/2018','04/06/2018','Apr','04/06/2018','','Graduated','QEA','Feb 2018','02/05/2018','Shafika','Kumaraguru College of Technology','BE','Civil','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','02/05/2018','04/06/2018','Apr','04/06/2018','','Graduated','QEA','Feb 2018','02/05/2018','Rohitha','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','02/05/2018','04/06/2018','Apr','04/06/2018','','Graduated','QEA','Feb 2018','02/05/2018','Vishveshrajeshvari','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','02/05/2018','04/06/2018','Apr','','','Intraining','QEA','Feb 2018','02/05/2018','Manoja Kumari','Kumaraguru College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','02/05/2018','04/06/2018','Apr','','','Intraining','QEA','Feb 2018','02/05/2018','Megeshi Kumari','Kumaraguru College of Technology','BE','Automobile','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','02/05/2018','04/06/2018','Apr','','','Intraining','QEA','Feb 2018','02/05/2018','Naveena','PSG College of Technology','BE','EIE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','02/05/2018','04/06/2018','Apr','','','Intraining','QEA','Feb 2018','02/05/2018','Aakashi','PSG College of Technology','BE','EIE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','02/05/2018','04/06/2018','Apr','','','Resigned','QEA','Feb 2018','02/05/2018','Kish Kumari','Karpagam College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Pune','PUN19QEA201','Naresh Shetty','GTP_CIME Tech Dot Net Testing','02/05/2018','04/06/2018','Apr','','','Resigned','QEA','Feb 2018','02/05/2018','Ram Kumari','Karpagam College of Technology','BE','EEE','PAT')





=========================================================================================================================================================================================================================================================================

--2018 apr to may

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/09/2018','05/28/2018','May','05/28/2018','','Graduated','AVM-AIM','Apr 2018','04/09/2018','Malarvannan','kandha College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/09/2018','05/28/2018','May','05/28/2018','','Graduated','AVM-AIM','Apr 2018','04/09/2018','Malar kannagi','kandha College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/09/2018','05/28/2018','May','05/28/2018','','Graduated','AVM-AIM','Apr 2018','04/09/2018','Manikam','Hosur College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/09/2018','05/28/2018','May','','','Intraining','AVM-AIM','Apr 2018','04/09/2018','Manikandan','Santhi College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/09/2018','05/28/2018','May','','','Intraining','AVM-AIM','Apr 2018','04/09/2018','Malar','Santhi College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/09/2018','05/28/2018','May','','','Intraining','AVM-AIM','Apr 2018','04/09/2018','Shreyas','kumaraguru College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/09/2018','05/28/2018','May','','','Intraining','AVM-AIM','Apr 2018','04/09/2018','Harish','Santhi College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/09/2018','05/28/2018','May','','','Intraining','AVM-AIM','Apr 2018','04/09/2018','Sujin','Veera College of Technology','BE','Mech','PAT')



INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','04/09/2018','05/28/2018','May','','','Intraining','AVM-AIM','Apr 2018','04/09/2018','Vasuki','Santhi College of Technology','BE','Civil','PAT')

===============================================================================================================================================================================================================================================================================

--2017 jan to march
INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','01/02/2017','03/16/2017','Jan','04/03/2017','','Graduated','AVM-AIM','Jan 2017','01/02/2017','Malarvannan','kandha College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','01/02/2017','03/16/2017','Jan','04/03/2017','','Graduated','AVM-AIM','Jan 2017','01/02/2017','Malar kannagi','kandha College of Technology','BE','EEE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','01/02/2017','03/16/2017','Jan','04/03/2017','','Graduated','AVM-AIM','Jan 2017','01/02/2017','Manikam','Hosur College of Technology','BE','ECE','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','01/02/2017','03/16/2017','Jan','','','Intraining','AVM-AIM','Jan 2017','01/02/2017','Manikandan','Santhi College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','01/02/2017','03/16/2017','Jan','','','Intraining','AVM-AIM','Jan 2017','01/02/2017','Malar','Santhi College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','01/02/2017','03/16/2017','Jan','','','Intraining','AVM-AIM','Jan 2017','01/02/2017','Shreyas','kumaraguru College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','01/02/2017','03/16/2017','Jan','','','Intraining','AVM-AIM','Jan 2017','01/02/2017','Harish','Santhi College of Technology','BE','Civil','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','01/02/2017','03/16/2017','Jan','','','Intraining','AVM-AIM','Jan 2017','01/02/2017','Sujin','Veera College of Technology','BE','Mech','PAT')



INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Kolkata','KOL19AVM102','Narmada','GTP_AVM - DW - Informatica Oracle','01/02/2017','03/16/2017','Jan','','','Intraining','AVM-AIM','Jan 2017','01/02/2017','Vasuki','Santhi College of Technology','BE','Civil','PAT')

==============================================================================================================================================================================================================================================================================

--2017 mar to apr


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','03/06/2017','04/14/2017','Apr','04/14/2017','','Graduated','AVM','Mar 2017','03/06/2017','Sureshi Kumari','Karpagam College of Technology','BE','BT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','03/06/2017','04/14/2017','Apr','04/14/2017','','Graduated','AVM','Mar 2017','03/06/2017','Rameshi Kumari','Karpagam College of Technology','BE','BT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','03/06/2017','04/14/2017','Apr','04/14/2017','','Graduated','AVM','Mar 2017','03/06/2017','Mangalya Kumari','Kumaraguru College of Technology','BE','Civil','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','03/06/2017','04/14/2017','Apr','','','Intraining','AVM','Mar 2017','03/06/2017','Nareshi','Krishna College of Technology','BE','FT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','03/06/2017','04/14/2017','Apr','','','Intraining','AVM','Mar 2017','03/06/2017','Bharat','Krishna College of Technology','BE','FT','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','03/06/2017','04/14/2017','Apr','','','Intraining','AVM','Mar 2017','03/06/2017','Sumesha','Krishna College of Technology','BE','Mechanical','PAT')

INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','03/06/2017','04/14/2017','Apr','','','Intraining','AVM','Mar 2017','03/06/2017','Mahathi','Kumaraguru College of Technology','BE','IT','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','03/06/2017','04/14/2017','Apr','','','Resigned','AVM','Mar 2017','03/06/2017','Yashik','SNS College of Technology','BE','FT','PAT')



INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','12/01/2019','12/30/2019','Dec','','','Resigned','AVM','Dec 2019','12/01/2019','Aashika','SNS College of Technology','BE','FT','PAT')



INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','11/01/2019','11/30/2019','Nov','','','Intraining','AVM','Nov 2019','11/01/2019','Sara','SNS College of Technology','BE','FT','PAT')



INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','10/01/2019','10/30/2019','Oct','','','Graduated','AVM','Oct 2019','10/01/2019','Saadhya','SNS College of Technology','BE','FT','PAT')








INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','12/01/2019','12/30/2019','Dec','','','Resigned','CDB','Dec 2019','12/01/2019','Manik','SNS College of Technology','BE','FT','PAT')



INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','11/01/2019','11/30/2019','Nov','','','Intraining','CDB','Nov 2019','11/01/2019','Parth','SNS College of Technology','BE','FT','PAT')



INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','10/01/2019','10/30/2019','Oct','','','Graduated','CDB','Oct 2019','10/01/2019','Anurag','SNS College of Technology','BE','FT','PAT')


INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','12/01/2019','12/30/2019','Dec','','','Resigned','QEA','Dec 2019','12/01/2019','Prerna','SNS College of Technology','BE','FT','PAT')



INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','11/01/2019','11/30/2019','Nov','','','Intraining','QEA','Nov 2019','11/01/2019','Disha','SNS College of Technology','BE','FT','PAT')



INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','10/01/2019','10/30/2019','Oct','','','Graduated','QEA','Oct 2019','10/01/2019','Niti','SNS College of Technology','BE','FT','PAT')






INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','12/01/2019','12/30/2019','Dec','','','Resigned','IS','Dec 2019','12/01/2019','Ranbir','SNS College of Technology','BE','FT','PAT')



INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','11/01/2019','11/30/2019','Nov','','','Intraining','IS','Nov 2019','11/01/2019','Rahat','SNS College of Technology','BE','FT','PAT')



INSERT into tabEmployeeDetails
(location,batchCode,batchOwnerName,track,batchStartDate,plannedGraduationDate,monthOfGraduation,actualGraduationDate,reasonForExtension,traineeStatus,trainingVertical,intakeMonth,dateOfJoining,associateName,collegeName,qualification,branch,designation) values
('Coimbatore','CBE19AVM002','A,Vigneshvaran','GTP_AVM_IS_Dotnet','10/01/2019','10/30/2019','Oct','','','Graduated','IS','Oct 2019','10/01/2019','Erica','SNS College of Technology','BE','FT','PAT')





===============================================================================================================================================================================================================================================================================

select count(*),traineeStatus from tabEmployeeDetails where   trainingVertical='IS' group by traineeStatus ;

SELECT trainingVertical from tabEmployeeDetails
select * from tabEmployeeDetails

drop table tabEmployeeDetails